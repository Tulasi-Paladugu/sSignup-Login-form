import React, { Component } from 'react';
import "bootstrap/dist/css/bootstrap.min.css"
import axios from 'axios'
class App extends React.Component {
  constructor(){
    super()
    this.state={
      fullName:'',
      userName:'',
      email:'',
      password:''
    }
    this.changeFullName=this.changeFullName.bind(this)
    this.changeUserName=this.changeUserName.bind(this)
    this.changeEmail=this.changeEmail.bind(this)
    this.changePassword=this.changePassword.bind(this)
    this.onSubmit=this.onSubmit.bind(this)
    this.validation=this.validation.bind(this)
  }
  changeFullName(event){
    this.setState({
      fullName:event.target.value
    })
  }
  changeUserName(event){
    this.setState({
      userName:event.target.value
    })
  }
  changeEmail(event){
    this.setState({
      email:event.target.value
    })
  }
  changePassword(event){
    this.setState({
      password:event.target.value
    })
  }
  onSubmit(event){
  event.preventDefault()
  const reg={
    fullName:this.state.fullName,
    userName:this.state.userName,
    email:this.state.email,
    password:this.state.password
  }
  axios.post('http://localhost:4000/app/signup',reg)
  .then(response=>{const ele=response.data
    console.log(ele);
  })
  this.setState({
    fullName:'',
    userName:'',
    email:'',
    password:''
  })
}
  validation(event){
  event.preventDefault()
    axios.get("http://localhost:4000/app/")
    .then(res=>{
      const ele=res.data;
      console.log(ele);
      for( var i=0;i<ele.length;i++){
      if(this.state.userName===ele[i].userName){
        if(this.state.password===ele[i].password){
        document.write("valid user");
        break;
        } 
        else{
          document.write("invalid user")
          break;
        }
        }
      }
    })
    .catch(()=>{console.log("error occured");});
  }
  render() { 
    return (
    <div className="container">
      <div className="form-div">
        <form onSubmit={this.onSubmit}>
         <input type="text" id="fname"
          placeholder="full name"
          onChange={this.changeFullName}
          value={this.state.fullName}
          className='form-contorl form-group'/>
          <input type='text'
          placeholder='user name'
          onChange={this.changeUserName}
          value={this.state.userName}
          className='form-control form-group'/>
          <input type="text" onChange={this.changeEmail}
          placeholder="email" value={this.state.email}
          className='form-control from-group'/>
          <input type="password"
          placeholder='password'
          onChange={this.changePassword}
          value={this.state.password}
          className='form-control form-group'/>
          <input type="submit" className='btn btn-danger btn-block' value='submit'/>
        
        </form>
        <div className="form2-div">
          <form onSubmit={this.validation}>
          <input type="text"
          placeholder="username"
          onChange={this.changeUserName}
          value={this.state.userName}
          className="form control form group"/>
          <input type="password" 
           placeholder="password"
           onChange={this.changePassword}
           value={this.state.password}
           className="form control form group"/>
          <input type="submit" className='btn btn-danger btn-block' value='vallidate'/>

           </form>
        </div>

      </div>
       
    </div>
    );
  }
}
 
export default App;