const express=require('express')
const router=express.Router()
const signuptemplatecopy=require('../models/signupModels')
router.get('/',(request,response)=>{
    signuptemplatecopy.find({})
    .then(routes=>response.json(routes))
    .catch(err=>response.json(err))
});
router.post('/signup',(request,response)=>{
    const signedupUser=new signuptemplatecopy ({
        fullName: request.body.fullName,
        userName: request.body.userName,
        email: request.body.email,
        password: request.body.password
    })
    signedupUser.save()
    .then(data=>{
        response.json(data)
    })
    .catch(error=>{
        response.json(error)
    })
})
module.exports = router